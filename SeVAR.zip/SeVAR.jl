# =============================================================================
#  Full Bayesian Analysis of Seasonal VAR (SeVAR) Models — Block (Group) SSVS
#  Companion code for Amin & Almuhayfith (2026), Mathematics.  
# =============================================================================

#--- used Packages
using LinearAlgebra, Distributions, Random, Statistics


# ---------------------------------------------------------------------------
_lag_label(l::Integer, p::Integer, s::Integer) =
    l <= p     ? "Theta_$l" :
    l % s == 0 ? "Omega_$(div(l, s))" :
                 "Cross_Theta$(l % s)_Omega$(div(l, s))"
#---------------------------------------------------------------------------
function analyzeSVAR_BlockSSVS(
    Yt::AbstractMatrix{<:Real}, p::Int, P::Int, s::Int, f_horizon::Int;
    ndraw::Int=10_000, nburn::Int=2_000, nthin::Int=10,
    eta::Real=0.01, zeta::Real=100.0, p_inc::Real=0.5, 
    kappa0::Union{Nothing,Int}=nothing,
    Xi0::Union{Nothing,AbstractMatrix{<:Real}}=nothing,
    rng::AbstractRNG=Random.default_rng()
)
    T, k = size(Yt)
    @assert (p >= 1 || P >= 1)  "at least one of p, P must be positive"
    @assert s > p  "s > p is required: keeps the three lag groups of Table 1 distinct (h = p+P+pP), makes the Eq. (9) signs unambiguous, and is assumed throughout the paper"
    @assert 0.0 < p_inc < 1.0   "p_inc must lie in (0, 1)"
    @assert zeta > 1.0          "slab must be wider than spike (zeta > 1)"
    Xi0 === nothing || @assert size(Xi0) == (k, k)  "Xi0 must be k × k"
    eta = Float64(eta); zeta = Float64(zeta); p_inc = Float64(p_inc)

    # ---- Lag structure of Table 1 -------------------------------------------
    lags        = vcat(1:p, s:s:(P*s), vec([i + j*s for i in 1:p, j in 1:P]))
    unique_lags = sort(unique(lags))
    h = length(unique_lags)
    @assert h == p + P + p*P    "lag collision: structural lags are not distinct"

    M     = maximum(unique_lags)
    N_eff = T - M
    n_x   = h * k                       # q
    @assert N_eff > n_x                 "n* must exceed q = h·k"

    # ---- Eq. (9) regressor signs ---------------------------------------------
    lag_sign = [ (l <= p || l % s == 0) ? 1.0 : -1.0 for l in unique_lags ]
    col_sign = repeat(lag_sign; inner = k)   # X is lag-major: k columns per lag

    # ---- Demeaning (no intercept in Eq. 3) -----------------------------------
    mean_Yt = vec(mean(Yt; dims=1))
    Y_full  = Yt .- mean_Yt'

    # ---- Design matrices (Eqs. 8–9) -------------------------------------------
    Y_eff = Y_full[M+1:end, :]
    X = Matrix{Float64}(undef, N_eff, n_x)
    for t in 1:N_eff
        t_old = M + t
        idx = 1
        for l in unique_lags, v in 1:k
            X[t, idx] = Y_full[t_old - l, v]
            idx += 1
        end
    end
    X .*= reshape(col_sign, 1, :)   
    XtX = Matrix(X'X)
    XtY = Matrix(X'Y_eff)
    dim_k2   = k * k
    num_beta = n_x * k

    # ---- Priors (§3.2) ---------------------------------------------------------
    t_spike   = eta                     
    t_slab    = zeta * eta              
    tau_spike = inv(t_spike^2)          
    tau_slab  = inv(t_slab^2)           
    S0 = Xi0 === nothing ? Matrix{Float64}(I, k, k) : Matrix{Float64}(Xi0)
    nu0     = kappa0 === nothing ? k + 1 : kappa0
    nu_post = N_eff + n_x + nu0         

    # ---- Initialisation  -----------
    B      = XtX \ XtY
    E0     = Y_eff - X * B
    Sigma  = Matrix(Symmetric(E0'E0 ./ N_eff))
    Lambda = inv(Sigma)
    delta  = ones(Int, h)
    #delta  = zeros(Int, h)
    qvec   = Vector{Float64}(undef, n_x)        
    for l in 1:h
        qvec[(l-1)*k+1 : l*k] .= tau_slab       
    end

    # ---- Storage -----------------------------------------------------------------
    nsaved         = div(ndraw, nthin)
    B_draws        = Array{Float64,3}(undef, n_x, k, nsaved)
    Lambda_draws   = Array{Float64,3}(undef, k, k, nsaved)
    Sigma_draws    = Array{Float64,3}(undef, k, k, nsaved)
    delta_draws    = Matrix{Int}(undef, h, nsaved)
    forecast_draws = Array{Float64,3}(undef, f_horizon, k, nsaved)
    x_f     = Vector{Float64}(undef, n_x)
    Yf_path = Matrix{Float64}(undef, M + f_horizon, k)
    hist    = @view Y_full[end-M+1:end, :]

    # ==========================================================================
    # Gibbs sweep 
    # ==========================================================================
    for iter in 1:(nburn + ndraw)

        # ---- STEP 1: 𝒦 | Λ, δ, Sₙ  (Theorem 1) --------------------------------
        A_delta = XtX + Diagonal(qvec)
        V_inv   = kron(Lambda, A_delta)
        C_V     = cholesky(Symmetric(V_inv))
        RHS     = vec(XtY * Lambda)                    
        B = reshape(C_V \ RHS + C_V.U \ randn(rng, num_beta), n_x, k)

        # ---- STEP 2: Λ | 𝒦, δ⁽ᵗ⁻¹⁾, Sₙ  (Theorem 2) ----------------------------
        E = Y_eff - X * B
        G = S0 + E'E + B' * (qvec .* B)     
        Lambda = rand(rng, Wishart(nu_post, Matrix(inv(Symmetric(G)))))
        Sigma  = inv(Lambda)

     
        # ---- STEP 3: δₘ | 𝒦, Λ, δ₋ₘ  (Theorem 3; log-ratio Eq. 38) ------------
        for l in 1:h        
            Bl  = @view B[(l-1)*k+1 : l*k, :]
            BtB = Bl'Bl
            ss  = dot(BtB, Lambda)          
            log_f1 = 0.5*dim_k2*log(tau_slab)  - 0.5*tau_slab *ss + log(p_inc)
            log_f0 = 0.5*dim_k2*log(tau_spike) - 0.5*tau_spike*ss + log(1.0 - p_inc)
            delta[l] = rand(rng) < inv(1.0 + exp(log_f0 - log_f1)) ? 1 : 0
            qvec[(l-1)*k+1 : l*k] .= (delta[l] == 1 ? tau_slab : tau_spike)
        end

        # ---- STEP 4: storage + stochastic forward simulation -------------------
        if iter > nburn && (iter - nburn) % nthin == 0
            sv = div(iter - nburn, nthin)
            B_draws[:, :, sv]      .= B
            Lambda_draws[:, :, sv] .= Lambda
            Sigma_draws[:, :, sv]  .= Sigma
            delta_draws[:, sv]      = delta

            C_sig = cholesky(Symmetric(Sigma))     

            Yf_path[1:M, :] .= hist
            for f in 1:f_horizon
                idx = 1
                for l in unique_lags, v in 1:k
                    x_f[idx] = Yf_path[M + f - l, v]  
                    idx += 1
                end
                x_f .*= col_sign   
                ydr = B' * x_f .+ C_sig.L * randn(rng, k)
                Yf_path[M + f, :] .= ydr
                forecast_draws[f, :, sv] .= ydr .+ mean_Yt
            end
        end
    end

    pips   = vec(mean(delta_draws; dims=2))
    labels = [_lag_label(l, p, s) for l in unique_lags]

    return Dict{String,Any}(
        "B" => B_draws, "Lambda" => Lambda_draws, "Sigma" => Sigma_draws,
        "delta" => delta_draws, "pips" => pips, "lags" => unique_lags,
        "labels" => labels, "forecasts" => forecast_draws,
        "h" => h, "q" => n_x, "n_eff" => N_eff,
    )
end
#---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# Simulated Example: SVAR₂(1,1)₅, n = 200
# ---------------------------------------------------------------------------
Random.seed!(2026)
T, k = 200, 2
Θ1 = [0.4 0.5; -0.2 -0.6];  Ω1 = [0.4 -0.3; -0.3 0.5];  Λtrue = [1.0 0.3; 0.3 1.0]
Cε = cholesky(Symmetric(inv(Λtrue)))
Y = zeros(T, k)
for t in 7:T     # note the −Θ₁Ω₁ cross term of Eq. (6)!
    Y[t, :] = Θ1*Y[t-1, :] + Ω1*Y[t-5, :] - (Θ1*Ω1)*Y[t-6, :] + Cε.L*randn(k)
end

out = analyzeSVAR_BlockSSVS(Y, 4, 4, 5, 5; rng = MersenneTwister(1))

out["labels"]                                     # block labels in row order of 𝒦
out["pips"]                                       # PIP̂ per structural lag block (Remark 3)
selected = out["pips"] .> 0.50                    # best-subset SVAR (PIP > 0.50)
dropdims(mean(out["B"];      dims=3), dims=3)     # posterior mean of 𝒦
dropdims(mean(out["Lambda"]; dims=3), dims=3)     # posterior mean of Λ
dropdims(mean(out["forecasts"]; dims=3), dims=3)  # point forecasts ŷ(n+r)



